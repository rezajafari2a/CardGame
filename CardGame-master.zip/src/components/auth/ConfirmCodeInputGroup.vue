<template>
  <div>
    <div class="confirm-code-input-group">
      <input
        v-for="(c, index) in confirmCodeArray"
        :key="index"
        ref="input"
        v-model="confirmCodeArray[index]"
        class="confirm-code-input"
        :class="{
          'confirm-code-input-error': isError,
        }"
        type="tel"
        @input="
          (e) => {
            onInput(e.target.value, index);
          }
        "
        @keydown.delete="
          (e) => {
            onKeydown(e.target.value, index);
          }
        "
        @focus="onFocus"
      />
    </div>

    <p v-show="isError" class="error-message d-flex justify-start">
      {{ errorName }}
    </p>
  </div>
</template>

<script>
import loginMixin from '../../mixins/index';
export default {
  mixins: [loginMixin],
  props: { isError: Boolean, errorName: String, tempOtpCode: String[5] },
  data() {
    return {
      confirmCodeArray: ['', '', '', '', ''],
      msg: '',
      isAutoLogin: false,
    };
  },
  computed: {
    confirmCodeArraySize() {
      return this.confirmCodeArray.length;
    },
    confirmCodeArrayIndex() {
      let i = this.confirmCodeArray.findIndex((item) => item === '');
      i =
        (i + this.confirmCodeArraySize) %
        this.confirmCodeArraySize;
      return i;
    },
    lastCode() {
      return this.confirmCodeArray[
        this.confirmCodeArraySize - 1
      ];
    },
  },
  watch: {
    tempOtpCode(val) {
      this.confirmCodeArray = val;
      this.$nextTick(() => {
        if (val) this.$emit('login');
      });
    },
    confirmCodeArray(val) {
      this.clearOtpCode();
      this.setOtpCode(this.toEnglishNumber(val.join('')));
      if (Math.ceil(Math.log(parseInt(val.join('')) + 1) / Math.LN10) === 5) {
        this.setOtpCode(val.join(''));
      }
      if (this.isAutoLogin) {
        this.$emit('login');
      }
    },
    confirmCodeArrayIndex() {
      this.resetCaret();
    },
    lastCode(val) {
      if (val) {
        this.$refs.input[
          this.confirmCodeArraySize - 1
        ].blur();
      }
    },
  },
  mounted() {
    this.resetCaret();
  },
  methods: {
    async submitOtpCode() {
      if (this.otpCode.length < 5) {
        this.errorResponse = true;
        this.erName = 'پر کردن این فیلد الزامی است';
      } else {
        try {
          const response = await this.requestLogin();
          if (response.status === 200) {
          } else {
            this.errorResponse = true;
            this.erName = response.message;
          }
        } catch (error) {}
      }
    },
    onInput(val, index) {
      this.msg = '';
      val = val.replace(/\s/g, '');
      if (index === this.confirmCodeArraySize - 1) {
        this.confirmCodeArray[this.confirmCodeArraySize - 1] =
          val[0]; // The last code, only one character is allowed.
        //automatic login if all input enterd
        let i = this.confirmCodeArray.findIndex(
          (item) => item === '' || item === undefined
        );
        if (i === -1) {
          this.isAutoLogin = true;
        } else {
          this.isAutoLogin = false;
        }
      } else if (val.length > 1) {
        let i = index;
        for (
          i = index;
          i < this.confirmCodeArraySize && i - index < val.length;
          i++
        ) {
          this.confirmCodeArray[i] = val[i];
        }
        this.resetCaret();
        this.isAutoLogin = false;
      }
    },
    // Reset the cursor position.
    resetCaret() {
      this.$refs.input[this.confirmCodeArraySize - 1].focus();
    },
    onFocus() {
      // Listen to the focus event and reposition the cursor to "the position of the first blank character".
      let index = this.confirmCodeArray.findIndex(
        (item) => item === ''
      );
      index =
        (index + this.confirmCodeArraySize) %
        this.confirmCodeArraySize;
      this.$refs.input[index].focus();
      this.$refs.input[index].style.backgroundColor = '#fefefe';
      this.$refs.input[index].style.border = '1px solid #003974';
    },
    onKeydown(val, index) {
      if (val === '') {
        // Delete the value in the previous input and focus on it.
        if (index > 0) {
          this.confirmCodeArray[index - 1] = '';
          this.$refs.input[index - 1].focus();
        }
      }
    },
    // sendCaptcha() {
    //   console.log()
    //   ;this.msg = `Send verification code to the server: ${this.confirmCodeArray.join(
    //     ''
    //   )}`
    // Input cannot be operated at this time. .
    //   ;this.loading = true
    //   setTimeout(() => {
    //     ;this.msg = 'Verification code error'
    //     ;this.loading = false
    //     ;this.$nextTick(() => {
    //       ;this.reset()
    //     })
    //   }, 3000)
    // },

    reset() {
      // Reset. It is usually triggered when the verification code is wrong.
      this.confirmCodeArray = this.confirmCodeArray.map(
        (item) => ''
      );
      this.resetCaret();
    },
  },
};
</script>

<style lang="scss" scoped>
.focuse-input {
  background-color: #fefefe;
  border: 1px solid #003974;
}
.captcha {
  display: flex;
  justify-content: center;
  margin-top: 40px;
}
input:disabled {
  color: #000;
  background-color: #fff;
}
.confirm-code-input {
  width: 55px;
  height: 55px;
  text-align: center;
  border: 1px solid rgba(43, 62, 115, 0.05);
  box-shadow: 0px 3px 2px rgba(43, 62, 115, 0.05);
  border-radius: 5px;
  margin: 0 0.5rem;
  background-color: #f2f2f2;
  outline: none;
  direction: ltr;
}
.confirm-code-input-error {
  border: 1px solid #f34440 !important;
  background-color: #ffebeb !important;
}
.confirm-code-input-group {
  display: grid;
  grid-template-columns: auto auto auto auto auto;
  direction: ltr;
}

.error-message {
  font-size: 0.875rem;
  color: #f34440;
  margin-top: 8px;
  margin-right: 8px;
}
</style>
