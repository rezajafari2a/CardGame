export default {
  methods: {
    toEnglishNumber(strNum) {
      if (strNum) {
        const pn = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];
        const ar = ["٠", "٩", "٨", "٧", "٦", "٥", "٤", "٣", "٢", "١"];
        const en = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];
        let converted = strNum;
        for (let i = 0; i < 10; i++) {
          const regex_fa = new RegExp(pn[i], "g");
          converted = converted.replace(regex_fa, en[i]);
        }
        for (let i = 0; i < 10; i++) {
          const regex_fa = new RegExp(ar[i], "g");
          converted = converted.replace(regex_fa, en[i]);
        }
        return converted;
      } else {
        return "";
      }
    },
  },
};
