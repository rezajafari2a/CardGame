<template>
  <div>
    <span class="formlable"> شماره موبایل خود را وارد نمایید </span>
  </div>
  <div class="phone-number-input-container">
    <input
      class="form-control"
      v-model="formData.phoneNumber"
      type="tel"
      placeholder="0912*******"
      maxlength="11"
      style="width: 50%"
      @input="setPhoneNumber"
      @click="changeStyle"
      @click:clear="formData.phoneNumber = ''"
    />
  </div>
  <p v-show="isError" class="error-message d-flex justify start mb-1">
    {{ errorName }}
  </p>
  <!-- <div class="row-rule">
        <div class="input__control">
          <label class="container">
            <input v-model="isAccepted" type="checkbox" />
            <span class="mark"></span>
          </label>
        </div>
        <p class="conditions-container">
          <a
            href="https://www.jeanswest.ir/%D8%B4%D8%B1%D8%A7%DB%8C%D8%B7-%D9%88-%D9%82%D9%88%D8%A7%D9%86%DB%8C%D9%86-%D8%AD%D8%B1%DB%8C%D9%85-%D8%AE%D8%B5%D9%88%D8%B5%DB%8C/"
          >
            شرایط و قوانین حریم خصوصی
          </a>
          مجموعه جین وست را می‌پذیرم
        </p>
      </div> -->
  <div class="confirm-code-container">
    <button
      width="100%"
      min-height="48px"
      outlined
      class="btn btn-primary bgbtn mt-3"
      @click="submitPhoneNumber"
    >
      دریافت کد تایید
    </button>
  </div>
</template>

<script>
import loginMixin from "../mixins/index";
import axios from "axios";
export default {
  name: "Auth",
  layout: "auth-layout",
  mixins: [loginMixin],
  data() {
    return {
      loading: false,
      isActivePhoneNumberInput: false,
      isActiveConfirmCode: false,
      isError: false,
      errorName: "",
      countriesDrawer: false,
      otpError: false,
      countryCode: "",
      isAccepted: true,
      formData: {
        phoneNumber: "",
      },
    };
  },
  watch: {
    formData: {
      handler(val) {
        try {
          if (val) {
            val.phoneNumber = this.toEnglishNumber(val.phoneNumber);
            val.phoneNumber.length === 11
              ? (this.isActiveConfirmCode = true)
              : (this.isActiveConfirmCode = false);
          }
        } catch (error) {
          console.log(error);
        }
      },
      deep: true,
    },
  },
  mounted() {
    this.formData.phoneNumber = this.$route.params.phoneNum;
    // const url_string = window.location.href;
    // const url = new URL(url_string);
  },
  methods: {
    setPhoneNumber() {
      this.formData.phoneNumber = this.toEnglishNumber(
        this.formData.phoneNumber
      );
    },
    async submitPhoneNumber() {
      if (this.formData.phoneNumber.match(/^(\+98|0)?9\d{9}$/) === null) {
        this.isError = true;
        this.errorName = "لطفا شماره تماس را به درستی وارد کنید";
      } else {
        try {
          this.loading = true;
          await axios
            .post("http://10.0.1.89:5000/api/v1/otp/request", {
              phoneNumber: parseInt(this.formData.phoneNumber),
            })
            .then((response) => {
              if (response.data.statusCode == 200) {
                this.$router.push({
                  name: "confirm-code",
                  params: { phoneNumber: this.formData.phoneNumber },
                });
              }
            })
            .catch((err) => {
              if (err.response.data.statusCode == 429) {
                this.isError = true;
                this.errorName = "لطفا پس از چند دقیقه مجددا تلاش کنید";
                this.loading = false;
              } else {
                this.isError = true;
                this.errorName = response.message;
                this.loading = false;
              }
            });
        } catch (e) {
          console.log(e);
        }
      }
    },
    changeStyle() {
      this.isActivePhoneNumberInput = true;
    },
  },
};
</script>

<style lang="scss" scoped>

.phone-number-input-container {
  padding: 1vh;
  display: flex;
  place-content: center;
}
.btn {
  display: inline-block;
  font-weight: 400;
  text-align: center;
  white-space: nowrap;
  vertical-align: middle;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  border: 1px solid transparent;
  padding: 0.375rem 0.75rem;
  font-size: 1rem;
  line-height: 1.5;
  border-radius: 0.25rem;
  transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out,
    border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}
.mt-3 {
  margin-top: 3vh;
}
.bgbtn {
  width: 90%;
}
.btn-primary {
  color: #fff;
  background-color: #2448ac;
  border-color: #007bff;
}
button:focus {
  outline: 1px dotted;
  outline: 5px auto #2448ac;
}
.btn-primary:not(:disabled):not(.disabled).active,
.btn-primary:not(:disabled):not(.disabled):active {
  color: #fff;
  background-color: #2448ac;
  border-color: #005cbf;
}
.countris-drawer-container {
  .v-navigation-drawer--bottom.v-navigation-drawer--is-mobile {
    max-height: 83%;
  }
}
.countries-input-container {
  background-color: #fff;
  padding: 1rem 1rem 0 1rem;
  position: absolute;
  width: 100%;
  top: 0;
  z-index: 1;
}
.countries-list-container {
  margin-top: 5.4rem;
}
.avatar-margin {
  margin-right: 15px;
}
//* checkbox css
.container {
  position: relative;
  cursor: pointer;
  font-size: 16px;
}

/* Hide the default checkbox */
.container input {
  visibility: hidden;
  cursor: pointer;
  align-items: center;
  span .mark {
    border-radius: 10px;
  }
}

/* Create a custom checkbox */
.mark {
  position: absolute;
  top: 20px;
  right: 0;
  height: 18px;
  width: 18px;
  background-color: #fff;
  border: solid 2px rgba(0, 0, 0, 0.6);
  border-radius: 2px;
}

.container input:checked ~ .mark {
  background-color: #32be93;
  border: solid 1px #32be93;
  border-radius: 2px;
}

//* Create the mark/indicator (hidden when not checked) */
.mark:after {
  content: "";
  position: absolute;
  top: 10px;
  display: none;
}

//* Show the mark when checked */
.container input:checked ~ .mark:after {
  display: block;
}

//* Style the mark/indicator */
.container .mark:after {
  left: 5px;
  top: 0px;
  width: 7px;
  height: 12px;
  border: solid white;
  border-width: 0 3px 3px 0;
  transform: rotate(45deg);
}
.form-control:focus {
  color: #495057;
  background-color: #fff;
  border-color: #80bdff;
  outline: 0;
  box-shadow: 0 0 0 0.2rem rgb(0 123 255 / 25%);
}
.form-control {
  display: block;
  width: 100%;
  padding: 0.375rem 0.75rem;
  font-size: 1.3rem;
  line-height: 1.5;
  color: #495057;
  background-color: #fff;
  background-clip: padding-box;
  border: 1px solid #ced4da;
  border-radius: 0.25rem;
  transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}
.row-rule {
  direction: rtl;
  display: flex;
  justify-content: center;
  width: 90%;
  margin: 3vh auto;
}
.input__control {
  margin: -6px 10px;
}
.formlable {
  display: block;
  width: 100%;
}
.error-message {
  font-size: 0.875rem;
  color: #f34440;
  margin-top: 8px;
}
</style>