<template>
  <div class="login-container">
    <div class="wrap-input-phone-number">
      <div class="wrap-input-phone-number">
        <div class="header-box">
          <img src="/img/wave.svg" />
        </div>
      </div>
      <router-view></router-view>
    </div>
  </div>
</template>
<script>
export default {
  name: "auth-layout",
};
</script>
<style lang="scss" scoped>
.login-container {
  height: 100vh;
  max-width: 600px;
  display: block;
  margin: auto;
}
.header-box {
  background-color: #2448ac;
  height: 40vh;
  display: flex;
  justify-content: center;
  align-items: flex-end;
  img {
    width: 100%;
    margin-bottom: -1px;
  }
}
</style>