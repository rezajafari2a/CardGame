import { createRouter, createWebHistory } from "vue-router";
import MainGame from "../views/MainGame.vue";
import Auth from "../views/auth.vue";
import ConfirmCode from "../views/confirm-code.vue";
import AuthLayout from "../layouts/auth-layout.vue";
const routes = [
  {
    path: "/",
    component: AuthLayout,
    children: [
      {
        name: "Auth",
        path: "",
        component: Auth,
      },
    ],
  },
  {
    path: "/game",
    name: "MainGame",
    component: MainGame,
  },
  {
    path: "/confirm-code",
    component: AuthLayout,
    children: [
      {
        name: "confirm-code",
        path: "",
        component: ConfirmCode,
      },
    ],
  },
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

export default router;
