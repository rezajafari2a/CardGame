<template>
  <div class="card" @click="clickFlip">
    <div class="card__inner" :class="isFlip ? 'is-flipped' : ''">
      <div class="card__face card__face--front">
        <img class="card__face__front--logo" src="/img/jeanswest.svg" />
        <span class="card__face__front--title">
          {{ title }}
        </span>
        <img class="card__face__front--corner" src="/img/cartpic.png" />
      </div>
      <div class="card__face card__face--back">
        <h2>پشت کارت</h2>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    title: {
      type: Number,
    },
    gameStatus: {
      required: true,
    },
  },
  data() {
    return {
      isFlip: false,
    };
  },
  methods: {
    clickFlip() {
      if (this.gameStatus == "STARTED") {
        this.isFlip = true;
        this.$emit("finish");
      }
    },
  },
  watch: {
    gameStatus(val) {
      if (val == "STARTED") {
        this.isFlip = false;
      }
    },
  },
};
</script>
<style scoped>
.card {
  width: 80%;
  height: 40vh;
  display: flex;
  place-items: center;
  place-content: center;
  border-radius: 15px;
  cursor: pointer;
  perspective: 1000px;
  max-width: 300px;
}
.card__inner.is-flipped {
  transform: rotateY(calc(3 * 180deg));
}
.card__face {
  position: absolute;
  width: 100%;
  height: 100%;
  -webkit-backface-visibility: hidden;
  backface-visibility: hidden;
  overflow: hidden;
  border-radius: 16px;
  box-shadow: 0px 3px 18px 3px rgba(0, 0, 0, 0.2);
}
.card__face--back {
  background-color: #f3f3f3;
  transform: rotateY(180deg);
}
.card__inner {
  width: 100%;
  height: 100%;
  transition: transform 1s;
  transform-style: preserve-3d;
  cursor: pointer;
  position: relative;
  display: flex;
  justify-content: center;
}
.card__face--front {
  background-image: linear-gradient(to bottom right, #f3f3f3, #fff);
  display: flex;
  align-items: center;
  justify-content: center;
  border: 5px solid #eceddc;
  align-items: baseline;
  justify-content: right;
}
.card__face__front--logo {
  width: 43%;
  transform: rotate(327.5deg);
  position: absolute;
  left: 0px;
  top: 14%;
}
.card__face__front--corner {
  width: 100%;
  position: absolute;
  bottom: 0px;
}
.card__face__front--title {
  font-size: 5rem;
  padding-bottom: 3rem;
  padding-right: 2vw;
  color: #1f4e77;
  z-index: 1;
}
</style>
