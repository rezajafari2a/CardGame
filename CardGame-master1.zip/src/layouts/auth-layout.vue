<template>
  <div class="login-container">
    <div class="wrap-input-phone-number">
      <div class="wrap-input-phone-number">
        <div class="header-box">
          <div class="amo-noroz"></div>
          <img src="/img/wave.svg" />
        </div>
      </div>
    </div>
    <footer>
      <router-view></router-view>
      <div class="footer">
        <img class="jeanswest-logo" src="/img/jeanswest.svg" />
        <img class="footer-wave" src="/img/wavefooter.svg" />
      </div>
    </footer>
  </div>
</template>
<script>
export default {
  name: "auth-layout",
};
</script>
<style lang="scss" scoped>
footer {
  height: 60vh;
  position: relative;
}
.footer {
  margin-top: 5vh;
  .jeanswest-logo {
    width: 90%;
  }
  .footer-wave {
    position: absolute;
    bottom: 0px;
    left: 0px;
  }
}
.amo-noroz {
  background-image: url("/img/Amo-Norouz-int.png");
  background-repeat: no-repeat;
  background-position: bottom right;
  display: block;
  width: 100%;
  height: 100%;
  z-index: 2;
  position: absolute;
  background-size: 50%;
}
.login-container {
  height: 100vh;
  max-width: 600px;
  display: block;
  margin: auto;
}
.header-box {
  background-color: #2448ac;
  position: relative;
  height: 40vh;
  img {
    width: 100%;
    bottom: 0px;
    position: absolute;
    left: 0px;
  }
}
</style>
