<template>
  <div dir="rtl">
    <div class="containerbox">
      <div class="wrap-input-phone-number">
        <div align="center" justify="center">
          <div class="d-flex justify-start phone-number">
            <p>
              کد تایید 5 رقمی ارسال شده به شماره موبایل
              {{ `${phoneNumber}` }} را وارد نمایید
              <!-- کد تایید برای شماره موبایل {{ `0${phoneNumber}` }} ارسال گردید -->
              <a href="#" class="edit-link" @click="goAuth">
                <img src="/img/edit.svg" alt="phone" class="edit-icon" />
                ویرایش شماره
              </a>
            </p>
          </div>
        </div>

        <div class="confirm-code-input-group-container">
          <ConfirmCodeInputGroup
            :is-error="errorResponse"
            :error-name="erName"
            @login="submitOtpCode"
            :tempOtpCode="tempOtpCode"
          />
        </div>
      </div>
      <div class="login-container-button mt-3">
        <btn
          width="100%"
          min-height="48px"
          class="btn btn-primary"
          color="#003974"
          :loading="loading"
          @click="submitOtpCode"
        >
          تایید
        </btn>
      </div>
      <div
        align="start"
        justify="center"
        class="d-flex justify-center align-start mt-5"
      >
        <p v-if="counter != 0" class="timer">
          ارسال مجدد کد تا {{ counter }} ثانیه دیگر
        </p>
        <p v-else>
          <a class="resend-code" href="#" @click="submitPhoneNumber">
            ارسال مجدد کد
          </a>
        </p>
      </div>
    </div>
  </div>
</template>

<script>
import ConfirmCodeInputGroup from "../components/auth/ConfirmCodeInputGroup.vue";
import loginMixin from "../mixins/index";
import axios from "axios";
export default {
  layout: "auth-layout",
  name: "ConfirmCode",
  components: {
    ConfirmCodeInputGroup,
  },
  mixins: [loginMixin],
  data() {
    return {
      counter: 150,
      erName: "",
      errorResponse: false,
      render: false,
      loading: false,
      tempOtpCode: String[5],
      phoneNumber: undefined,
    };
  },
  mounted() {
    this.addOtpListener();
    this.phoneNumber = this.$route.params.phoneNumber
      ? this.$route.params.phoneNumber
      : "";
    if (this.phoneNumber === "" || this.phoneNumber == undefined) {
      // this.$router.push({
      //   name: "Auth",
      // });
    } else {
      this.render = true;
      this.countDownTimer();
    }
  },
  methods: {
    addOtpListener() {
      if ("OTPCredential" in window) {
        const ac = new AbortController();
        navigator.credentials
          .get({
            otp: { transport: ["sms"] },
            signal: ac.signal,
          })
          .then((result) => {
            this.otpCode = result?.code;
            this.tempOtpCode = result?.code.split("");
          })
          .catch((err) => {
            console.log(err);
          });
      }
    },
    goAuth() {
      const phoneNum = `0${this.phoneNumber}`;
      this.$router.push({
        name: "Auth",
      });
    },
    countDownTimer() {
      const interval = setInterval(() => {
        this.counter--;
        if (this.counter === 0) {
          clearInterval(interval);
        }
      }, 1000);
      return this.counter;
    },
    resetCountDown() {
      this.counter = 150;
      this.countDownTimer();
    },
    async submitOtpCode() {
      this.loading = true;
      if (this.otpCode.length < 5) {
        this.errorResponse = true;
        this.erName = "پر کردن این فیلد الزامی است";
      } else {
        try {
          //   const response = await (this).requestLogin();
          //   if ((this).isResponseSuccess(response.status)) {
          //     response.data.data.registration
          //       ? (this).createFireBaseEvent('register')
          //       : (this).createFireBaseEvent('login');
          //     (this).invitationCode === null
          //       ? (this).$router.go(-2)
          //       : (this).$router.push({ name: 'profile' });
          //   } else {
          //     (this).errorResponse = true;
          //     (this).erName = response.message;
          //   }
        } catch (error) {}
      }
      this.loading = false;
    },
    async submitPhoneNumber() {
      try {
        await axios
          .post("http://10.0.1.89:5000/api/v1/otp/request", {
            phoneNumber: "9102467671",
          })
          .then((response) => {
            if (response.status === 200 || response.status === 201) {
              this.resetCountDown();
            } else {
              this.isError = true;
              this.errorName = response.message;
            }
          });
      } catch (e) {}
    },
  },
};
</script>

<style lang="scss" scoped>
.containerbox {
  width: 90%;
  display: block;
  margin: auto;
}
.edit-icon {
  margin-left: 10px;
}
.phone-number {
  font-size: 16px;
  text-align: right;
}
.confirm-code-input-group-container {
  display: flex;
  justify-content: center;
  margin-top: 1.5rem;
}
.edit-link {
  text-decoration: none;
  color: black;
}

.edit-phone-number {
  margin-top: 2%;
  margin-right: 8%;
  direction: ltr;
  color: black;
}
.timer {
  margin-left: 2%;
  direction: ltr;
  color: #929292;
  font-size: 16px;
}

.confirm-num-icon {
  height: 12.5%;
}
.border-drawer {
  width: 100%;
  padding: 10px;
  height: 62.5%;
  border-top-left-radius: 40px;
  border-top-right-radius: 40px;
  border-bottom: none;
  border-right: none;
  border-left: none;
}
.resend-code {
  text-decoration: none;
  color: black;
  font-size: 1rem;
  font-weight: bold;
}
.d-flex {
  display: flex;
}
.btn {
  display: inline-block;
  font-weight: 400;
  text-align: center;
  white-space: nowrap;
  vertical-align: middle;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
  border: 1px solid transparent;
  padding: 0.375rem 0.75rem;
  font-size: 1rem;
  line-height: 1.5;
  border-radius: 0.25rem;
  transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out,
    border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
}
.mt-3 {
  margin-top: 3vh;
}
.bgbtn {
  width: 90%;
}
.btn-primary {
  color: #fff;
  background-color: #2448ac;
  border-color: #007bff;
  cursor: pointer;
}
button:focus {
  outline: 1px dotted;
  outline: 5px auto #2448ac;
}
.btn-primary:not(:disabled):not(.disabled).active,
.btn-primary:not(:disabled):not(.disabled):active {
  color: #fff;
  background-color: #2448ac;
  border-color: #005cbf;
}
</style>
