<template>
  <div class="bodygame">
    <div class="main-game">
      <div class="card-wraper">
        <Card
          v-for="i in 4"
          :key="i"
          :gameStatus="gameStatus"
          :title="i"
          @finish="finishGame"
        />
      </div>
      <div class="gameend" v-if="gameStatus != gameStatusList.STARTED">
        <div class="innerbox-game">
          <button class="btn-game" @click="starGame">شروع بازی</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Card from "@/components/card";
export default {
  name: "MainGame",
  components: { Card },
  data() {
    return {
      gameStatusList: { START: "START", STARTED: "STARTED", END: "END" },
      gameStatus: undefined,
    };
  },
  mounted() {
    this.gameStatus = this.gameStatusList.NONE;
  },
  methods: {
    finishGame() {
      this.gameStatus = this.gameStatusList.END;
    },
    starGame() {
      this.gameStatus = this.gameStatusList.STARTED;
    },
  },
};
</script>
<style scoped>
.bodygame {
  background-image: url(/img/gamebackground.jpg);
  background-color: #051320;
  background-blend-mode: multiply;
}
.btn-game:hover {
  transform: scale(1.1);
  transition: transform 0.2s;
}
.btn-game {
  padding: 15px 25px;
  text-align: center;
  width: 100%;
  border-radius: 10px;
  border: none;
  cursor: pointer;
  font-size: large;
  outline: 5px solid rgb(221 139 82);
  animation: glow 1s ease-in-out infinite alternate;
  box-shadow: 0px 15px 32px #2b2b2b;
}
@keyframes glow {
  from {
    text-shadow: 0 0 0px #fff, 0 0 0px #fff, 0 0 1px #fff, 0 0 1px #fff,
      0 0 1px #fff, 0 0 1px #fff, 0 0 1px #fff;
  }
  to {
    text-shadow: 0 0 2px #fff, 0 0 2px #28da78, 0 0 2px #28da78, 0 0 2px #28da78,
      0 0 1px #28da78, 0 0 1px #28da78, 0 0 1px #28da78;
  }
}
.innerbox-game {
  background-image: url("/img/wooden board_4622294-min.png");
  width: 100%;
  max-width: 400px;
  margin: auto;
  top: 35vh;
  height: 100%;
  max-height: 400px;
  background-size: contain;
  background-repeat: no-repeat;
  display: grid;
  justify-content: center;
  align-items: center;
  transform-origin: bottom center;
  animation: swing-top-fwd 1s cubic-bezier(0.455, 0.03, 0.515, 0.955) both;
}
@keyframes swing-top-fwd {
  0% {
    transform: translateY(150px) translateZ(-230px) rotateX(90deg);
  }
  100% {
    transform: translateY(0) translateZ(0) rotateX(0deg);
  }
}
.gameend {
  width: 100vw;
  height: 100vh;
  background-color: rgb(27 26 26 / 62%);
  position: absolute;
  top: 0px;
  right: 0px;
  display: grid;
  max-width: 1200px;
}
.main-game {
  max-width: 1200px;
  margin: auto;
  background-color: #225684;
  height: 100vh;
  width: 100%;
  position: relative;
}
.card-wraper {
  display: grid;
  grid-template-columns: 1fr 1fr;
  place-items: center center;
  height: 100%;
  padding: 0px 10px;
}
</style>
